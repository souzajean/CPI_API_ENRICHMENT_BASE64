import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Base64

def Message processData(Message message) {
    def body = message.getBody(String)
    def encoded = Base64.encoder.encodeToString(body.getBytes("UTF-8"))
    message.setBody(encoded)
    return message
}