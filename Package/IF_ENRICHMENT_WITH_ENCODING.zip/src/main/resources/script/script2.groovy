import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Base64

def Message processData(Message message) {
    def body = message.getBody(String)
    def decoded = new String(Base64.decoder.decode(body), "UTF-8")
    message.setBody(decoded)
    return message
}